This project was started by Thomas Fussell.

It was initially inspired by the openpyxl library: https://openpyxl.readthedocs.org

Thanks to everyone who has contributed to this project (in alphabetical order):

* adam-nielsen
* Malvineous
* sukoi26
* tpmccallum
* xpol

Project logo designed by Thomas Fussell.
